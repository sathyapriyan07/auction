
import React, { useState } from 'react';
import { X, UserPlus, Link as LinkIcon, BarChart3 } from 'lucide-react';
import { Player, PlayerRole } from '../types';

interface AddPlayerFormProps {
  onAdd: (player: Player) => void;
  onClose: () => void;
}

export const AddPlayerForm: React.FC<AddPlayerFormProps> = ({ onAdd, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    role: PlayerRole.BATSMAN,
    nationality: 'India',
    basePrice: 0.5,
    image: '',
    matches: 0,
    runs: 0,
    wickets: 0,
    strikeRate: 0,
    economy: 0,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPlayer: Player = {
      id: `manual-${Date.now()}`,
      name: formData.name,
      role: formData.role,
      nationality: formData.nationality,
      basePrice: formData.basePrice,
      stats: {
        matches: formData.matches,
        runs: formData.runs,
        wickets: formData.wickets,
        strikeRate: formData.strikeRate,
        economy: formData.economy,
      },
      image: formData.image || 'https://picsum.photos/seed/' + Math.random() + '/400/400',
    };
    onAdd(newPlayer);
    onClose();
  };

  const handleNumberChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value === '' ? 0 : parseFloat(value) });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 w-full max-w-lg rounded-3xl border border-slate-800 shadow-2xl overflow-hidden animate-slideIn my-8">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center sticky top-0 bg-slate-900 z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 rounded-xl text-indigo-400">
              <UserPlus size={20} />
            </div>
            <h3 className="font-black text-sm uppercase tracking-widest text-white">Add Individual Player</h3>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Basic Info Section */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <span className="w-4 h-px bg-indigo-400/30"></span> Basic Information
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Player Name</label>
                <input 
                  required
                  type="text" 
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g. Virat Kohli"
                  className="w-full bg-slate-800 border-slate-700 border-2 rounded-xl px-4 py-3 text-sm text-white font-bold outline-none focus:border-indigo-600 transition-all" 
                />
              </div>
              
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Role</label>
                <select 
                  value={formData.role}
                  onChange={e => setFormData({...formData, role: e.target.value as PlayerRole})}
                  className="w-full bg-slate-800 border-slate-700 border-2 rounded-xl px-4 py-3 text-xs text-white font-bold outline-none cursor-pointer"
                >
                  {Object.values(PlayerRole).map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Base Price (Cr)</label>
                <input 
                  type="number" 
                  step="0.1"
                  min="0.1"
                  value={formData.basePrice}
                  onChange={e => handleNumberChange('basePrice', e.target.value)}
                  className="w-full bg-slate-800 border-slate-700 border-2 rounded-xl px-4 py-3 text-xs text-white font-bold outline-none focus:border-indigo-600 transition-all" 
                />
              </div>

              <div className="col-span-2 space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 flex items-center gap-1">
                  <LinkIcon size={10} /> Image Link
                </label>
                <input 
                  type="url" 
                  value={formData.image}
                  onChange={e => setFormData({...formData, image: e.target.value})}
                  placeholder="https://example.com/player_photo.png"
                  className="w-full bg-slate-800 border-slate-700 border-2 rounded-xl px-4 py-3 text-xs text-white font-bold outline-none focus:border-indigo-600 transition-all" 
                />
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <span className="w-4 h-px bg-indigo-400/30"></span> Career Statistics <BarChart3 size={12} />
            </h4>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Matches</label>
                <input 
                  type="number" 
                  value={formData.matches}
                  onChange={e => handleNumberChange('matches', e.target.value)}
                  className="w-full bg-slate-800/50 border-slate-700 border-2 rounded-xl px-3 py-2.5 text-[11px] text-white font-bold outline-none focus:border-indigo-600" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Runs</label>
                <input 
                  type="number" 
                  value={formData.runs}
                  onChange={e => handleNumberChange('runs', e.target.value)}
                  className="w-full bg-slate-800/50 border-slate-700 border-2 rounded-xl px-3 py-2.5 text-[11px] text-white font-bold outline-none focus:border-indigo-600" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Wickets</label>
                <input 
                  type="number" 
                  value={formData.wickets}
                  onChange={e => handleNumberChange('wickets', e.target.value)}
                  className="w-full bg-slate-800/50 border-slate-700 border-2 rounded-xl px-3 py-2.5 text-[11px] text-white font-bold outline-none focus:border-indigo-600" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Strike Rate</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={formData.strikeRate}
                  onChange={e => handleNumberChange('strikeRate', e.target.value)}
                  className="w-full bg-slate-800/50 border-slate-700 border-2 rounded-xl px-3 py-2.5 text-[11px] text-white font-bold outline-none focus:border-indigo-600" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Economy</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={formData.economy}
                  onChange={e => handleNumberChange('economy', e.target.value)}
                  className="w-full bg-slate-800/50 border-slate-700 border-2 rounded-xl px-3 py-2.5 text-[11px] text-white font-bold outline-none focus:border-indigo-600" 
                />
              </div>
            </div>
          </div>

          {formData.image && (
            <div className="pt-2 flex items-center gap-4 bg-slate-800/50 p-3 rounded-2xl border border-slate-700">
              <div className="w-16 h-16 rounded-xl overflow-hidden border-2 border-slate-600 shrink-0">
                <img 
                  src={formData.image} 
                  alt="Preview" 
                  className="w-full h-full object-cover"
                  onError={(e) => (e.currentTarget.src = 'https://picsum.photos/400/400')}
                />
              </div>
              <div>
                <p className="text-[8px] font-black text-indigo-400 uppercase tracking-widest">Live Preview</p>
                <p className="text-[10px] text-slate-400 font-bold truncate max-w-[200px]">{formData.image}</p>
                <div className="flex gap-2 mt-1">
                   <span className="text-[8px] bg-slate-700 px-1.5 py-0.5 rounded text-slate-300 font-bold">{formData.runs} Runs</span>
                   <span className="text-[8px] bg-slate-700 px-1.5 py-0.5 rounded text-slate-300 font-bold">{formData.wickets} Wkts</span>
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-indigo-600 py-4 rounded-2xl font-black text-xs uppercase tracking-widest text-white hover:bg-indigo-500 shadow-xl shadow-indigo-600/20 transition-all mt-4 transform active:scale-[0.98]"
          >
            Add to Auction Pool
          </button>
        </form>
      </div>
    </div>
  );
};
